# Memory Knowledge

Agent Zero plugin for querying and writing to the Supabase `memory` schema.

## Configuration

Preferred mode is Supabase Data API:

```text
auth.mode=data_api
supabase.url=https://ufgbtyrdwngayrrutfdz.supabase.co
SUPABASE_SERVICE_ROLE_KEY=...
```

The `memory` schema must be exposed in the Supabase project's Data API settings.

Postgres URL mode is still available with `auth.mode=postgres` and one of:

```text
MEMORY_DATABASE_URL
SUPABASE_DB_URL
DATABASE_URL
```

Optional tenant and agent settings:

```text
MEMORY_TENANT_ID=<uuid>
MEMORY_TENANT_SLUG=agent-zero
MEMORY_AGENT_KEY=agent0:zero
```

If `MEMORY_TENANT_ID` is omitted, the plugin uses `MEMORY_TENANT_SLUG` and creates the tenant when writes are enabled.

## Tools

`MemoryHealth` verifies connectivity and reports table counts.

`MemoryQuery` supports:

- `target="memory"` with `query`, optional `kinds`, `limit`, `include_inactive`
- `target="knowledge"` with `query`, optional `limit`
- `target="table"` with `table`, optional equality `filters`, `limit`

`MemoryWrite` supports:

- `action="memory"` to create `memory.memory_items`
- `action="knowledge"` to upsert documents and chunks
- `action="run"` to upsert `memory.run_history`
- `action="run_message"` to upsert `memory.run_messages`
- `action="run_step"` to upsert `memory.run_steps`
- `action="run_thought"` to upsert `memory.run_thoughts`
- `action="tool_execution"` to insert `memory.tool_executions`

Writes are tenant-scoped and constrained to known schema operations. The plugin does not expose arbitrary SQL mutation to the agent.

## Lifecycle Automation

The plugin includes deterministic Python extensions for:

- `agent_init`: load plugin runtime settings.
- `message_loop_start`: create a `memory.run_history` row.
- `message_loop_prompts_before`: retrieve active memory and inject a context block.
- `response_stream`: capture assistant response chunks.
- `monologue_start` / `monologue_end`: record monologue steps and thoughts when those extension points are available.
- `tool_execution_start` / `tool_execution_end`: record tool steps and tool execution rows when those extension points are available.
- `message_loop_end`: write run messages, finalize the run, and create cue-matched candidate memories with evidence.

Candidate memory extraction is rule-based. It only writes when configured cues such as `remember`, `prefer`, `workflow`, or `this repo` appear in the turn text.
