from __future__ import annotations

from helpers.tool import Response, Tool

from usr.plugins.memory_knowledge.helpers import db
from usr.plugins.memory_knowledge.helpers.runtime import settings_for_agent


class MemoryWrite(Tool):
    """Write tenant-scoped records to memory, knowledge, and run-history tables."""

    async def execute(self, **kwargs):
        try:
            settings = settings_for_agent(getattr(self, "agent", None))
            action = str(self.args.get("action") or "memory").strip().lower()

            if action in {"memory", "create_memory", "save_memory"}:
                result = db.create_memory(settings, self.args)
            elif action in {"knowledge", "upsert_knowledge", "knowledge_document"}:
                result = db.upsert_knowledge_document(settings, self.args)
            elif action in {"run", "log_run"}:
                result = db.log_run(settings, self.args)
            elif action in {"run_message", "message", "log_message"}:
                result = db.log_run_message(settings, self.args)
            elif action in {"run_step", "step", "log_step"}:
                result = db.log_run_step(settings, self.args)
            elif action in {"run_thought", "thought", "log_thought"}:
                result = db.log_run_thought(settings, self.args)
            elif action in {"tool_execution", "tool", "log_tool_execution"}:
                result = db.log_tool_execution(settings, self.args)
            else:
                return Response(
                    message=(
                        "Unsupported action. Use action='memory', 'knowledge', "
                        "'run', 'run_message', 'run_step', 'run_thought', "
                        "or 'tool_execution'."
                    ),
                    break_loop=False,
                )
            return Response(message=db.dump_json({"ok": True, "result": result}), break_loop=False)
        except Exception as exc:
            return Response(message=db.dump_json({"ok": False, "error": str(exc)}), break_loop=False)
