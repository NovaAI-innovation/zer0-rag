from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from typing import Any, Mapping

from usr.plugins.memory_knowledge.helpers import db
from usr.plugins.memory_knowledge.helpers.runtime import MemoryRuntime


def _jsonable(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Mapping):
        return {str(k): _jsonable(v) for k, v in value.items() if not str(k).startswith("_")}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value[:50]]
    return str(value)


def _stable_key(*parts: Any) -> str:
    raw = "|".join(str(part or "") for part in parts)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:24]


def _agent_name(agent: Any) -> str:
    for attr in ("name", "agent_name", "profile", "profile_name"):
        value = getattr(agent, attr, None)
        if value:
            return str(value)
    return "Agent Zero"


def _model_name(agent: Any, kwargs: Mapping[str, Any]) -> str | None:
    for key in ("model", "model_name"):
        if kwargs.get(key):
            return str(kwargs[key])
    for attr in ("model", "model_name"):
        value = getattr(agent, attr, None)
        if value:
            return str(value)
    return None


def text_from_kwargs(kwargs: Mapping[str, Any], *extra_keys: str) -> str:
    for key in (*extra_keys, "message", "user_message", "prompt", "input", "content", "text"):
        value = kwargs.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
        if isinstance(value, Mapping) and isinstance(value.get("content"), str):
            return value["content"].strip()
    return ""


def latest_user_text(agent: Any, kwargs: Mapping[str, Any]) -> str:
    direct = text_from_kwargs(kwargs)
    if direct:
        return direct
    history = getattr(agent, "history", None) or getattr(agent, "messages", None)
    if isinstance(history, list):
        for item in reversed(history):
            if isinstance(item, Mapping) and item.get("role") == "user" and item.get("content"):
                return str(item["content"]).strip()
    return ""


def assistant_text(runtime: MemoryRuntime, kwargs: Mapping[str, Any]) -> str:
    direct = text_from_kwargs(kwargs, "response", "assistant_message", "output", "final_response")
    return direct or "".join(runtime.response_chunks).strip()


def begin_turn(agent: Any, runtime: MemoryRuntime, kwargs: Mapping[str, Any]) -> None:
    runtime.turn_index += 1
    runtime.started_at = datetime.now(timezone.utc)
    runtime.response_chunks.clear()
    runtime.injected_memory_ids.clear()
    runtime.injected_memory_block = ""
    runtime.step_index = 0
    runtime.thought_index = 0
    runtime.thread_key = str(
        kwargs.get("thread_id")
        or kwargs.get("conversation_id")
        or kwargs.get("chat_id")
        or getattr(agent, "context_id", None)
        or getattr(agent, "id", None)
        or "agent-zero"
    )
    user_text = latest_user_text(agent, kwargs)
    runtime.run_key = str(kwargs.get("run_key") or f"{runtime.thread_key}:{runtime.turn_index}:{_stable_key(user_text)}")
    if not runtime.settings.record_run_history:
        return
    result = db.log_run(
        runtime.settings,
        {
            "run_key": runtime.run_key,
            "agent_name": _agent_name(agent),
            "model": _model_name(agent, kwargs),
            "operation": "message_loop.turn",
            "status": "running",
            "input_text": user_text or None,
            "input_payload": {
                "thread_key": runtime.thread_key,
                "turn_index": runtime.turn_index,
                "hook": "message_loop_start",
            },
            "metadata": {"deterministic": True, "source": "memory_knowledge"},
        },
    )
    runtime.run_id = str(result["id"])


def capture_response_chunk(runtime: MemoryRuntime, kwargs: Mapping[str, Any]) -> None:
    for key in ("chunk", "content", "delta", "text", "response"):
        value = kwargs.get(key)
        if isinstance(value, str) and value:
            runtime.response_chunks.append(value)
            return
        if isinstance(value, Mapping):
            content = value.get("content") or value.get("delta")
            if isinstance(content, str) and content:
                runtime.response_chunks.append(content)
                return


def record_step(runtime: MemoryRuntime, name: str, step_type: str, kwargs: Mapping[str, Any], status: str = "succeeded") -> None:
    if not runtime.run_id or not runtime.settings.record_steps:
        return
    runtime.step_index += 1
    sequence = int(kwargs.get("sequence_number") or kwargs.get("step_index") or runtime.step_index)
    db.log_run_step(
        runtime.settings,
        {
            "run_id": runtime.run_id,
            "sequence_number": sequence,
            "step_type": step_type,
            "name": name,
            "status": status,
            "input_payload": _jsonable(dict(kwargs)),
            "metadata": {"deterministic": True, "source": "memory_knowledge"},
        },
    )


def record_tool_call(runtime: MemoryRuntime, kwargs: Mapping[str, Any]) -> None:
    if not runtime.run_id or not runtime.settings.record_tool_calls:
        return
    tool_name = kwargs.get("tool_name") or kwargs.get("name") or kwargs.get("tool")
    if not tool_name:
        return
    db.log_tool_execution(
        runtime.settings,
        {
            "run_id": runtime.run_id,
            "tool_call_id": kwargs.get("tool_call_id") or kwargs.get("call_id"),
            "tool_name": str(tool_name),
            "input_payload": kwargs.get("input") or kwargs.get("args") or kwargs.get("arguments") or {},
            "output_payload": kwargs.get("output") or kwargs.get("result"),
            "stdout_text": kwargs.get("stdout"),
            "stderr_text": kwargs.get("stderr"),
            "status": str(kwargs.get("status") or "succeeded"),
            "duration_ms": kwargs.get("duration_ms"),
            "error_code": kwargs.get("error_code"),
            "error_message": kwargs.get("error") or kwargs.get("error_message"),
            "metadata": {"deterministic": True, "hook": "tool"},
        },
    )


def record_thought(runtime: MemoryRuntime, kwargs: Mapping[str, Any]) -> None:
    if not runtime.run_id or not runtime.settings.record_thoughts:
        return
    content = text_from_kwargs(kwargs, "thought", "monologue", "reasoning", "summary")
    if not content:
        return
    runtime.thought_index += 1
    db.log_run_thought(
        runtime.settings,
        {
            "run_id": runtime.run_id,
            "sequence_number": int(kwargs.get("sequence_number") or kwargs.get("thought_index") or runtime.thought_index),
            "thought_type": str(kwargs.get("thought_type") or "summary"),
            "content_text": content,
            "visibility": str(kwargs.get("visibility") or "internal"),
        },
    )


def finish_turn(agent: Any, runtime: MemoryRuntime, kwargs: Mapping[str, Any]) -> dict[str, Any]:
    user_text = latest_user_text(agent, kwargs)
    response_text = assistant_text(runtime, kwargs)
    result: dict[str, Any] = {"run_id": runtime.run_id, "messages": 0}
    if runtime.run_id and runtime.settings.record_messages:
        ordinal = 1
        if user_text:
            db.log_run_message(
                runtime.settings,
                {
                    "run_id": runtime.run_id,
                    "role": "user",
                    "ordinal": ordinal,
                    "content_text": user_text,
                    "metadata": {"deterministic": True},
                },
            )
            result["messages"] += 1
            ordinal += 1
        if runtime.injected_memory_block:
            db.log_run_message(
                runtime.settings,
                {
                    "run_id": runtime.run_id,
                    "role": "system",
                    "ordinal": ordinal,
                    "content_text": runtime.injected_memory_block,
                    "metadata": {"type": "injected_memory", "memory_ids": runtime.injected_memory_ids},
                },
            )
            result["messages"] += 1
            ordinal += 1
        if response_text:
            db.log_run_message(
                runtime.settings,
                {
                    "run_id": runtime.run_id,
                    "role": "assistant",
                    "ordinal": ordinal,
                    "content_text": response_text,
                    "metadata": {"deterministic": True},
                },
            )
            result["messages"] += 1
    if runtime.run_key and runtime.settings.record_run_history:
        elapsed = int((datetime.now(timezone.utc) - runtime.started_at).total_seconds() * 1000)
        updated = db.log_run(
            runtime.settings,
            {
                "run_key": runtime.run_key,
                "operation": "message_loop.turn",
                "status": "succeeded",
                "response_text": response_text or None,
                "duration_ms": elapsed,
                "metadata": {
                    "deterministic": True,
                    "source": "memory_knowledge",
                    "messages_recorded": result["messages"],
                },
            },
        )
        runtime.run_id = str(updated["id"])
        result["run"] = updated
    return result
