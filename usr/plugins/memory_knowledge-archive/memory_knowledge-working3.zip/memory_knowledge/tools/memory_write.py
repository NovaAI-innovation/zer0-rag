from __future__ import annotations

from helpers.tool import Response, Tool

from usr.plugins.memory_knowledge.helpers import db
from usr.plugins.memory_knowledge.helpers.runtime import settings_for_agent


class MemoryWrite(Tool):
    """Write tenant-scoped records to memory, knowledge, and run-history tables."""

    async def execute(self, **kwargs):
        try:
            settings = settings_for_agent(getattr(self, "agent", None))
            action = str(self.args.get("action") or "memory").strip().lower()

            if action in {"memory", "create_memory", "save_memory"}:
                result = db.create_memory(settings, self.args)
            elif action in {"knowledge", "upsert_knowledge", "knowledge_document"}:
                result = db.upsert_knowledge_document(settings, self.args)
            elif action in {"run", "log_run"}:
                result = db.log_run(settings, self.args)
            elif action in {"run_message", "message", "log_message"}:
                result = db.log_run_message(settings, self.args)
            elif action in {"run_step", "step", "log_step"}:
                result = db.log_run_step(settings, self.args)
            elif action in {"run_thought", "thought", "log_thought"}:
                result = db.log_run_thought(settings, self.args)
            elif action in {"promote_memory", "promote", "activate_memory"}:
                result = db.promote_memory(settings, str(self.args.get("memory_item_id") or self.args.get("id") or ""), self.args.get("reason"))
            elif action in {"reinforce_memory", "reinforce", "confirm_memory"}:
                result = db.adjust_memory_confidence(
                    settings,
                    str(self.args.get("memory_item_id") or self.args.get("id") or ""),
                    float(self.args.get("delta") or settings.memory_evidence_confidence_delta),
                    self.args.get("reason") or "manual_reinforcement",
                    self.args.get("support_score"),
                )
            elif action in {"weaken_memory", "weaken", "correct_memory"}:
                result = db.adjust_memory_confidence(
                    settings,
                    str(self.args.get("memory_item_id") or self.args.get("id") or ""),
                    float(self.args.get("delta") or settings.memory_correction_confidence_delta),
                    self.args.get("reason") or "manual_correction",
                    self.args.get("support_score"),
                )
            elif action in {"reject_memory", "reject"}:
                memory_id = str(self.args.get("memory_item_id") or self.args.get("id") or "")
                db.adjust_memory_confidence(
                    settings,
                    memory_id,
                    float(self.args.get("delta") or settings.memory_correction_confidence_delta),
                    self.args.get("reason") or "manual_rejection",
                    self.args.get("support_score"),
                )
                result = db.set_memory_status(settings, memory_id, "rejected", self.args.get("reason") or "manual_rejection")
            elif action in {"tool_execution", "tool", "log_tool_execution"}:
                result = db.log_tool_execution(settings, self.args)
            else:
                return Response(
                    message=(
                        "Unsupported action. Use action='memory', 'knowledge', "
                        "'run', 'run_message', 'run_step', 'run_thought', "
                        "'promote_memory', 'reinforce_memory', 'weaken_memory', "
                        "'reject_memory', or 'tool_execution'."
                    ),
                    break_loop=False,
                )
            return Response(message=db.dump_json({"ok": True, "result": result}), break_loop=False)
        except Exception as exc:
            return Response(message=db.dump_json({"ok": False, "error": str(exc)}), break_loop=False)
